import type { SceneName } from '../components/SceneArt'

export type Poster = {
  title: string
  genre: string
  from: string
  to: string
  scene: SceneName
}

/** Pôsteres 100% fictícios, gerados com SVG/CSS. Não representam obras reais. */
export const posters: Poster[] = [
  { title: 'Noite Escarlate', genre: 'Suspense', from: '#14c957', to: '#04200f', scene: 'city' },
  { title: 'Órbita 9', genre: 'Ficção', from: '#4f46e5', to: '#0b0b2e', scene: 'space' },
  { title: 'Rodada Final', genre: 'Esportes', from: '#22c55e', to: '#031a0d', scene: 'stadium' },
  { title: 'Limite Zero', genre: 'Ação', from: '#ff7a2d', to: '#2b0d05', scene: 'figure' },
  { title: 'Céu de Cinza', genre: 'Romance', from: '#f43f5e', to: '#240a10', scene: 'bokeh' },
  { title: 'Eco Profundo', genre: 'Drama', from: '#0ea5a4', to: '#04222a', scene: 'ocean' },
  { title: 'A Última Sessão', genre: 'Mistério', from: '#a21caf', to: '#1d0524', scene: 'rays' },
  { title: 'Clássico de Domingo', genre: 'Esportes', from: '#0ea5e9', to: '#04162a', scene: 'stadium' },
  { title: 'Neon & Sombra', genre: 'Crime', from: '#ec4899', to: '#1f0a18', scene: 'city' },
  { title: 'Vórtice', genre: 'Aventura', from: '#eab308', to: '#2a1f04', scene: 'mountains' },
]
