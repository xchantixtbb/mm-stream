import { ArrowRight } from 'lucide-react'
import Button from '../components/Button'
import Icon from '../components/Icon'
import Reveal from '../components/Reveal'
import SectionHeading from '../components/SectionHeading'
import { siteConfig } from '../config/site'
import { buildWhatsAppLink } from '../lib/whatsapp'

export default function HowItWorks() {
  const { howItWorks } = siteConfig

  return (
    <section id="como-funciona" aria-labelledby="como-funciona-title" className="section-y relative">
      <div className="container-x">
        <Reveal>
          <SectionHeading
            id="como-funciona-title"
            eyebrow={howItWorks.eyebrow}
            title={howItWorks.title}
            subtitle={howItWorks.subtitle}
          />
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {howItWorks.steps.map((step, index) => (
            <Reveal key={step.number} delay={index * 120} className="h-full">
              <article className="group relative h-full overflow-hidden rounded-3xl border border-white/10 bg-white/[0.03] p-7 transition-all duration-300 hover:-translate-y-1.5 hover:border-brand-500/40 hover:bg-white/[0.06] sm:p-8">
                <span
                  className="pointer-events-none absolute -right-2 -top-4 font-display text-8xl font-extrabold text-white/[0.05] transition-colors duration-300 group-hover:text-brand-500/15"
                  aria-hidden="true"
                >
                  {step.number}
                </span>
                <div className="relative">
                  <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-500/25 to-brand-700/10 text-brand-400 ring-1 ring-brand-500/30">
                    <Icon name={step.icon} size={26} />
                  </span>
                  <p className="mt-6 font-display text-sm font-bold tracking-widest text-brand-400">
                    PASSO {step.number}
                  </p>
                  <h3 className="mt-2 font-display text-xl font-bold sm:text-2xl">{step.title}</h3>
                  <p className="mt-3 text-white/70">{step.text}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12 flex justify-center">
          <Button href={buildWhatsAppLink()} external size="lg" className="w-full sm:w-auto">
            {howItWorks.cta}
            <ArrowRight size={18} aria-hidden="true" />
          </Button>
        </Reveal>
      </div>
    </section>
  )
}
