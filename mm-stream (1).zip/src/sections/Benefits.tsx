import Button from '../components/Button'
import Icon from '../components/Icon'
import Reveal from '../components/Reveal'
import SectionHeading from '../components/SectionHeading'
import { siteConfig } from '../config/site'
import { buildWhatsAppLink } from '../lib/whatsapp'

export default function Benefits() {
  const { benefits } = siteConfig

  return (
    <section id="beneficios" aria-labelledby="beneficios-title" className="section-y relative">
      <div
        className="pointer-events-none absolute inset-x-0 top-1/2 -z-10 mx-auto h-96 max-w-3xl -translate-y-1/2 rounded-full bg-brand-700/10 blur-[120px]"
        aria-hidden="true"
      />
      <div className="container-x">
        <Reveal>
          <SectionHeading
            id="beneficios-title"
            eyebrow={benefits.eyebrow}
            title={benefits.title}
            subtitle={benefits.subtitle}
          />
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {benefits.items.map((item, index) => (
            <Reveal key={item.title} delay={(index % 4) * 80} className="h-full">
              <article className="h-full rounded-3xl border border-white/10 bg-white/[0.03] p-6 transition-all duration-300 hover:-translate-y-1.5 hover:border-brand-500/40 hover:bg-white/[0.06] hover:shadow-glow">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand-500/25 to-brand-700/10 text-brand-400 ring-1 ring-brand-500/30">
                  <Icon name={item.icon} size={24} />
                </span>
                <h3 className="mt-5 font-display text-lg font-bold leading-snug">{item.title}</h3>
                <p className="mt-2 text-sm text-white/70 sm:text-base">{item.text}</p>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-12 flex justify-center">
          <Button href={buildWhatsAppLink()} external variant="secondary" size="lg" className="w-full sm:w-auto">
            {benefits.cta}
          </Button>
        </Reveal>
      </div>
    </section>
  )
}
