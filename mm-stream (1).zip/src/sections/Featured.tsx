import { ArrowRight } from 'lucide-react'
import Button from '../components/Button'
import PosterCard from '../components/PosterCard'
import Reveal from '../components/Reveal'
import { siteConfig } from '../config/site'
import { posters, type Poster } from '../data/posters'
import { buildWhatsAppLink } from '../lib/whatsapp'

type MarqueeProps = {
  items: Poster[]
  reverse?: boolean
}

function MarqueeRow({ items, reverse = false }: MarqueeProps) {
  const loop = [...items, ...items]

  return (
    <div className="fade-edges overflow-hidden" aria-hidden="true">
      <div className={`marquee-track flex w-max ${reverse ? 'animate-marquee-reverse' : 'animate-marquee'}`}>
        {loop.map((poster, index) => (
          <div key={`${poster.title}-${index}`} className="w-28 shrink-0 pr-4 sm:w-36 lg:w-40">
            <PosterCard poster={poster} />
          </div>
        ))}
      </div>
    </div>
  )
}

export default function Featured() {
  const { featured } = siteConfig
  const reversed = [...posters].reverse()

  return (
    <section id="destaque" aria-labelledby="destaque-title" className="section-y relative">
      <div className="container-x">
        <Reveal>
          <div className="relative isolate overflow-hidden rounded-[2rem] border border-white/10 bg-ink-900">
            <div className="pointer-events-none absolute inset-0 -z-10" aria-hidden="true">
              <div className="absolute -top-32 left-1/2 h-72 w-[640px] max-w-none -translate-x-1/2 animate-glow rounded-full bg-brand-600/30 blur-[110px]" />
              <div className="bg-grid absolute inset-0 opacity-70" />
            </div>

            <div className="px-6 pb-10 pt-14 text-center sm:px-12 sm:pt-20">
              <span className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-brand-400">
                <span className="h-px w-6 bg-brand-500" aria-hidden="true" />
                {featured.eyebrow}
              </span>
              <h2
                id="destaque-title"
                className="mx-auto mt-5 max-w-3xl font-display text-3xl font-extrabold leading-tight sm:text-5xl"
              >
                {featured.titleLead} <span className="text-gradient animate-shift">{featured.titleHighlight}</span>
              </h2>
              <p className="mx-auto mt-5 max-w-2xl text-base text-white/70 sm:text-lg">{featured.text}</p>

              <ul className="mt-7 flex flex-wrap justify-center gap-3">
                {featured.pills.map((pill) => (
                  <li
                    key={pill}
                    className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-white/85"
                  >
                    {pill}
                  </li>
                ))}
              </ul>

              <div className="mt-9 flex justify-center">
                <Button href={buildWhatsAppLink()} external size="lg" className="w-full sm:w-auto">
                  {featured.cta}
                  <ArrowRight size={18} aria-hidden="true" />
                </Button>
              </div>
            </div>

            <div className="space-y-4 pb-12">
              <MarqueeRow items={posters} />
              <MarqueeRow items={reversed} reverse />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
