import type { CSSProperties } from 'react'
import { ArrowRight, Check } from 'lucide-react'
import Button from '../components/Button'
import HeroVisual from '../components/HeroVisual'
import { siteConfig } from '../config/site'
import { buildWhatsAppLink } from '../lib/whatsapp'

const delay = (ms: number): CSSProperties => ({ animationDelay: `${ms}ms` })

export default function Hero() {
  const { hero } = siteConfig

  return (
    <section
      id="inicio"
      aria-labelledby="hero-title"
      className="relative isolate overflow-hidden pb-16 pt-28 sm:pt-32 lg:pb-24 lg:pt-36"
    >
      <div className="pointer-events-none absolute inset-0 -z-10" aria-hidden="true">
        <div className="absolute -top-40 left-1/2 h-[520px] w-[820px] max-w-none -translate-x-1/2 animate-glow rounded-full bg-brand-600/25 blur-[120px]" />
        <div className="absolute right-[-10%] top-1/3 h-72 w-72 rounded-full bg-brand-400/10 blur-[100px]" />
        <div className="bg-grid absolute inset-0" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink to-transparent" />
      </div>

      <div className="container-x grid items-center gap-14 lg:grid-cols-[1.05fr_0.95fr] lg:gap-8">
        <div className="text-center lg:text-left">
          <p
            className="inline-flex animate-fade-up items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-white/80 sm:text-sm"
            style={delay(0)}
          >
            <span className="h-2 w-2 rounded-full bg-brand-500" aria-hidden="true" />
            {hero.eyebrow}
          </p>

          <h1
            id="hero-title"
            className="mt-6 animate-fade-up font-display text-4xl font-extrabold leading-[1.08] sm:text-5xl lg:text-6xl xl:text-7xl"
            style={delay(100)}
          >
            <span className="mb-4 block text-sm font-extrabold tracking-[0.5em] text-brand-400 sm:text-base">
              {siteConfig.name}
            </span>
            {hero.titleLine1}{' '}
            <span className="text-gradient animate-shift">{hero.titleHighlight}</span>
          </h1>

          <p
            className="mx-auto mt-6 max-w-xl animate-fade-up text-base text-white/75 sm:text-lg lg:mx-0"
            style={delay(200)}
          >
            {hero.subtitle}
          </p>

          <div
            className="mt-9 flex animate-fade-up flex-col items-stretch gap-4 sm:flex-row sm:items-center sm:justify-center lg:justify-start"
            style={delay(300)}
          >
            <Button href={buildWhatsAppLink()} external size="lg" className="sm:w-auto">
              {hero.primaryCta}
              <ArrowRight size={18} aria-hidden="true" />
            </Button>
            <Button href="#como-funciona" variant="secondary" size="lg" className="sm:w-auto">
              {hero.secondaryCta}
            </Button>
          </div>

          <ul
            className="mt-9 flex animate-fade-up flex-wrap justify-center gap-x-6 gap-y-3 text-sm text-white/70 lg:justify-start"
            style={delay(400)}
          >
            {hero.highlights.map((item) => (
              <li key={item} className="inline-flex items-center gap-2">
                <Check size={16} className="text-brand-400" aria-hidden="true" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <HeroVisual />
      </div>
    </section>
  )
}
