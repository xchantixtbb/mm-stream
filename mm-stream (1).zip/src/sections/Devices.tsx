import Icon from '../components/Icon'
import Reveal from '../components/Reveal'
import { siteConfig } from '../config/site'

export default function Devices() {
  const { devices } = siteConfig

  return (
    <section aria-labelledby="dispositivos-title" className="relative py-10 sm:py-14">
      <div className="container-x">
        <Reveal>
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.03] px-6 py-10 text-center sm:px-10">
            <ul className="flex flex-wrap items-center justify-center gap-6">
              {devices.items.map((item) => (
                <li key={item.label} className="flex flex-col items-center gap-3">
                  <span className="grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-brand-500/25 to-brand-700/10 text-brand-400 ring-1 ring-brand-500/30 shadow-glow">
                    <Icon name={item.icon} size={40} />
                  </span>
                  <span className="font-display text-sm font-bold uppercase tracking-widest text-white/85">
                    {item.label}
                  </span>
                </li>
              ))}
            </ul>
            <h2 id="dispositivos-title" className="mt-6 font-display text-2xl font-extrabold sm:text-3xl">
              {devices.title}
            </h2>
            <p className="mx-auto mt-2 max-w-xl text-white/70">{devices.subtitle}</p>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
