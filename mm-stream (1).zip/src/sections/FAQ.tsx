import { useState } from 'react'
import { ChevronDown } from 'lucide-react'
import Button from '../components/Button'
import Reveal from '../components/Reveal'
import SectionHeading from '../components/SectionHeading'
import { siteConfig } from '../config/site'
import { buildWhatsAppLink } from '../lib/whatsapp'

export default function FAQ() {
  const { faq } = siteConfig
  const [openId, setOpenId] = useState<string | null>(faq.items[0]?.id ?? null)

  return (
    <section id="faq" aria-labelledby="faq-title" className="section-y relative">
      <div className="container-x">
        <Reveal>
          <SectionHeading id="faq-title" eyebrow={faq.eyebrow} title={faq.title} subtitle={faq.subtitle} />
        </Reveal>

        <div className="mx-auto mt-12 max-w-3xl space-y-3">
          {faq.items.map((item, index) => {
            const isOpen = openId === item.id
            const buttonId = `faq-button-${item.id}`
            const panelId = `faq-panel-${item.id}`

            return (
              <Reveal key={item.id} delay={Math.min(index, 4) * 60}>
                <div
                  className={`rounded-2xl border transition-colors duration-300 ${
                    isOpen
                      ? 'border-brand-500/50 bg-white/[0.06]'
                      : 'border-white/10 bg-white/[0.03] hover:border-white/25'
                  }`}
                >
                  <h3>
                    <button
                      id={buttonId}
                      type="button"
                      aria-expanded={isOpen}
                      aria-controls={panelId}
                      onClick={() => setOpenId(isOpen ? null : item.id)}
                      className="flex w-full items-center justify-between gap-4 rounded-2xl px-5 py-5 text-left font-display text-base font-semibold sm:px-6 sm:text-lg"
                    >
                      <span>{item.question}</span>
                      <ChevronDown
                        size={20}
                        aria-hidden="true"
                        className={`shrink-0 text-brand-400 transition-transform duration-300 ${
                          isOpen ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                  </h3>
                  <div
                    id={panelId}
                    role="region"
                    aria-labelledby={buttonId}
                    aria-hidden={!isOpen}
                    className={`grid transition-[grid-template-rows] duration-300 ease-out ${
                      isOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'
                    }`}
                  >
                    <div className="overflow-hidden">
                      <p className="px-5 pb-5 text-white/70 sm:px-6">{item.answer}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            )
          })}
        </div>

        <Reveal className="mt-10 flex flex-col items-center gap-4 text-center">
          <p className="text-white/70">{faq.moreDoubts}</p>
          <Button href={buildWhatsAppLink()} external variant="secondary" size="md">
            {faq.moreDoubtsCta}
          </Button>
        </Reveal>
      </div>
    </section>
  )
}
