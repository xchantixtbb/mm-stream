import Icon from '../components/Icon'
import Reveal from '../components/Reveal'
import SceneArt from '../components/SceneArt'
import SectionHeading from '../components/SectionHeading'
import { siteConfig } from '../config/site'

export default function Categories() {
  const { categories } = siteConfig

  return (
    <section id="categorias" aria-labelledby="categorias-title" className="section-y relative">
      <div className="container-x">
        <Reveal>
          <SectionHeading
            id="categorias-title"
            eyebrow={categories.eyebrow}
            title={categories.title}
            subtitle={categories.subtitle}
          />
        </Reveal>

        <ul className="mt-14 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {categories.items.map((item, index) => (
            <li key={item.label} className="last:col-span-2 sm:last:col-span-1">
              <Reveal delay={index * 80} className="h-full">
                <div
                  className="group relative flex h-full min-h-[14rem] flex-col justify-end overflow-hidden rounded-3xl border border-white/10 p-5 transition-all duration-300 hover:-translate-y-1.5 hover:border-brand-500/60 hover:shadow-glow sm:min-h-[19rem]"
                  style={{ background: `linear-gradient(165deg, ${item.from} 0%, ${item.to} 100%)` }}
                >
                  <SceneArt scene={item.scene} />
                  <div
                    className="absolute inset-0"
                    style={{ background: 'radial-gradient(circle at 85% 8%, rgba(255,255,255,0.25), transparent 45%)' }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
                  <div className="relative">
                    <span className="grid h-11 w-11 place-items-center rounded-full bg-black/45 text-brand-400 ring-1 ring-brand-500/50">
                      <Icon name={item.icon} size={22} />
                    </span>
                    <h3 className="mt-3 font-display text-lg font-bold">{item.label}</h3>
                    <p className="mt-1 text-sm text-white/75">{item.text}</p>
                  </div>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
