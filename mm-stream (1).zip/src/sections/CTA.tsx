import { ArrowRight } from 'lucide-react'
import Button from '../components/Button'
import Reveal from '../components/Reveal'
import { PHONE_DISPLAY, PHONE_TEL, siteConfig } from '../config/site'
import { buildWhatsAppLink } from '../lib/whatsapp'

export default function CTA() {
  const { cta } = siteConfig

  return (
    <section id="contato" aria-labelledby="cta-title" className="section-y">
      <div className="container-x">
        <Reveal>
          <div className="relative isolate overflow-hidden rounded-[2rem] border border-brand-500/30 bg-gradient-to-br from-brand-800 via-[#06301a] to-ink-900 px-6 py-14 text-center sm:px-12 sm:py-20">
            <div className="pointer-events-none absolute inset-0 -z-10" aria-hidden="true">
              <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-brand-400/30 blur-[90px]" />
              <div className="absolute -bottom-24 -left-16 h-72 w-72 rounded-full bg-brand-500/20 blur-[100px]" />
              <div className="bg-grid absolute inset-0 opacity-50" />
            </div>

            <div className="mx-auto max-w-3xl">
              <h2
                id="cta-title"
                className="font-display text-3xl font-extrabold leading-tight sm:text-5xl"
              >
                {cta.title}
              </h2>
              <p className="mx-auto mt-5 max-w-xl text-base text-white/85 sm:text-lg">{cta.text}</p>

              <div className="mt-9 flex flex-col items-center gap-4">
                <Button
                  href={buildWhatsAppLink()}
                  external
                  variant="light"
                  size="lg"
                  className="w-full animate-pulse-ring sm:w-auto"
                >
                  {cta.button}
                  <ArrowRight size={18} aria-hidden="true" />
                </Button>
                <p className="text-sm text-white/80">{cta.note}</p>
                <a
                  href={PHONE_TEL}
                  className="rounded-full border border-white/25 bg-black/30 px-6 py-3 font-display text-lg font-bold tracking-wide transition-colors hover:bg-black/50"
                >
                  {PHONE_DISPLAY}
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
