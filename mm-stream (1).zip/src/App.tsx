import Footer from './components/Footer'
import Navbar from './components/Navbar'
import WhatsAppButton from './components/WhatsAppButton'
import Benefits from './sections/Benefits'
import Categories from './sections/Categories'
import CTA from './sections/CTA'
import Devices from './sections/Devices'
import FAQ from './sections/FAQ'
import Featured from './sections/Featured'
import Hero from './sections/Hero'
import HowItWorks from './sections/HowItWorks'

export default function App() {
  return (
    <>
      <a
        href="#conteudo"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-white focus:px-5 focus:py-3 focus:text-sm focus:font-bold focus:text-ink"
      >
        Pular para o conteúdo
      </a>
      <Navbar />
      <main id="conteudo">
        <Hero />
        <Categories />
        <HowItWorks />
        <Benefits />
        <Devices />
        <Featured />
        <FAQ />
        <CTA />
      </main>
      <Footer />
      <WhatsAppButton />
    </>
  )
}
