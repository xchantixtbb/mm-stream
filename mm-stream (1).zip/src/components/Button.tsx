import type { ReactNode } from 'react'

type Variant = 'primary' | 'secondary' | 'light'
type Size = 'sm' | 'md' | 'lg'

type Props = {
  href: string
  children: ReactNode
  variant?: Variant
  size?: Size
  external?: boolean
  className?: string
  onClick?: () => void
  ariaLabel?: string
}

const variantClasses: Record<Variant, string> = {
  primary: 'btn-primary',
  secondary: 'btn-secondary',
  light: 'btn-light',
}

const sizeClasses: Record<Size, string> = {
  sm: 'btn-sm',
  md: 'btn-md',
  lg: 'btn-lg',
}

export default function Button({
  href,
  children,
  variant = 'primary',
  size = 'md',
  external = false,
  className = '',
  onClick,
  ariaLabel,
}: Props) {
  return (
    <a
      href={href}
      onClick={onClick}
      aria-label={ariaLabel}
      target={external ? '_blank' : undefined}
      rel={external ? 'noopener noreferrer' : undefined}
      className={`btn ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
    >
      {children}
    </a>
  )
}
