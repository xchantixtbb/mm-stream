import { siteConfig } from '../config/site'

type Props = {
  className?: string
}

export default function Logo({ className = '' }: Props) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <svg width="30" height="30" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
        <defs>
          <linearGradient id="logo-gradient" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#6dffa0" />
            <stop offset="1" stopColor="#0e9441" />
          </linearGradient>
        </defs>
        <rect width="64" height="64" rx="16" fill="url(#logo-gradient)" />
        <path d="M25 18 L47 32 L25 46 Z" fill="#07070a" />
      </svg>
      <span className="font-display text-lg font-extrabold uppercase tracking-[0.14em]">{siteConfig.name}</span>
    </span>
  )
}
