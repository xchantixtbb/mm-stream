import { MessageCircle } from 'lucide-react'
import { buildWhatsAppLink } from '../lib/whatsapp'

export default function WhatsAppButton() {
  return (
    <a
      href={buildWhatsAppLink()}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar com a M&M Stream no WhatsApp"
      className="fixed bottom-[max(1.25rem,env(safe-area-inset-bottom))] right-[max(1.25rem,env(safe-area-inset-right))] z-40 grid h-14 w-14 animate-wa-pulse place-items-center rounded-full bg-[#25D366] text-white shadow-[0_10px_30px_-8px_rgba(37,211,102,0.7)] transition-transform duration-300 hover:scale-110 sm:h-16 sm:w-16"
    >
      <MessageCircle size={28} aria-hidden="true" />
    </a>
  )
}
