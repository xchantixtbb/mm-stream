import type { ReactNode } from 'react'
import { Facebook, Instagram, MessageCircle } from 'lucide-react'
import { siteConfig } from '../config/site'
import { buildWhatsAppLink } from '../lib/whatsapp'
import Logo from './Logo'
import TikTokIcon from './TikTokIcon'

type SocialItem = {
  id: string
  label: string
  href: string
  icon: ReactNode
}

export default function Footer() {
  const { footer, social } = siteConfig

  const socials: SocialItem[] = [
    { id: 'instagram', label: 'Instagram', href: social.instagram, icon: <Instagram size={18} aria-hidden="true" /> },
    { id: 'whatsapp', label: 'WhatsApp', href: buildWhatsAppLink(), icon: <MessageCircle size={18} aria-hidden="true" /> },
    { id: 'tiktok', label: 'TikTok', href: social.tiktok, icon: <TikTokIcon size={18} /> },
    { id: 'facebook', label: 'Facebook', href: social.facebook, icon: <Facebook size={18} aria-hidden="true" /> },
  ]

  const socialBase =
    'grid h-11 w-11 place-items-center rounded-full border border-white/15 bg-white/5 transition-all duration-300'

  return (
    <footer className="relative border-t border-white/10 bg-ink-900">
      <div className="container-x py-14 sm:py-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr_1fr]">
          <div>
            <a href="#inicio" aria-label={`${siteConfig.name} — ir para o início`} className="inline-block rounded-md">
              <Logo />
            </a>
            <p className="mt-4 max-w-xs text-white/70">{siteConfig.tagline}</p>
          </div>

          <nav aria-label="Rodapé — navegação">
            <h2 className="font-display text-sm font-bold uppercase tracking-widest text-white">Navegação</h2>
            <ul className="mt-4 space-y-3">
              {footer.navLinks.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-white/70 transition-colors hover:text-white">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Rodapé — legal">
            <h2 className="font-display text-sm font-bold uppercase tracking-widest text-white">Legal</h2>
            <ul className="mt-4 space-y-3">
              {footer.legalLinks.map((link) => (
                <li key={link.label}>
                  <a href={link.href} className="text-white/70 transition-colors hover:text-white">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h2 className="font-display text-sm font-bold uppercase tracking-widest text-white">Redes sociais</h2>
            <ul className="mt-4 flex flex-wrap gap-3">
              {socials.map((item) => (
                <li key={item.id}>
                  {item.href ? (
                    <a
                      href={item.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={item.label}
                      className={`${socialBase} hover:-translate-y-0.5 hover:border-brand-500/60 hover:bg-brand-600/20 hover:shadow-glow`}
                    >
                      {item.icon}
                    </a>
                  ) : (
                    <span
                      aria-label={`${item.label} (em breve)`}
                      title="Em breve"
                      className={`${socialBase} cursor-not-allowed opacity-40`}
                    >
                      {item.icon}
                    </span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-6 text-sm text-white/60">{footer.copyright}</div>
      </div>
    </footer>
  )
}
