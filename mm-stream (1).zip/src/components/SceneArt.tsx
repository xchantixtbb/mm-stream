import type { ReactNode } from 'react'

export type SceneName =
  | 'city'
  | 'space'
  | 'mountains'
  | 'stadium'
  | 'rays'
  | 'ocean'
  | 'figure'
  | 'bokeh'

const windows: Array<[number, number]> = [
  [6, 200], [14, 215], [6, 235], [30, 172], [37, 190], [30, 215], [56, 218], [66, 238], [58, 262],
  [82, 162], [92, 182], [84, 205], [92, 232], [112, 206], [120, 226], [114, 256], [140, 182],
  [152, 200], [142, 232], [174, 212], [186, 236], [176, 262],
]

const stars: Array<[number, number, number]> = [
  [20, 30, 1.2], [60, 18, 1], [95, 50, 1.4], [170, 25, 1.2], [185, 80, 1], [30, 110, 1],
  [150, 170, 1.2], [15, 200, 1], [180, 210, 1.4], [70, 260, 1], [110, 20, 1],
]

const bokeh: Array<[number, number, number, number]> = [
  [40, 70, 22, 0.16], [150, 50, 30, 0.12], [165, 130, 16, 0.2], [30, 160, 28, 0.1],
  [110, 100, 12, 0.22], [75, 40, 10, 0.18], [135, 190, 24, 0.1], [55, 230, 14, 0.14],
]

const scenes: Record<SceneName, ReactNode> = {
  city: (
    <>
      <circle cx="140" cy="95" r="38" fill="#fff" fillOpacity="0.2" />
      <circle cx="140" cy="95" r="62" stroke="#fff" strokeOpacity="0.12" />
      <g fill="#000" fillOpacity="0.55">
        <rect x="0" y="190" width="28" height="110" />
        <rect x="24" y="160" width="22" height="140" />
        <rect x="50" y="205" width="30" height="95" />
        <rect x="76" y="150" width="26" height="150" />
        <rect x="106" y="195" width="24" height="105" />
        <rect x="134" y="170" width="30" height="130" />
        <rect x="168" y="200" width="32" height="100" />
      </g>
      <g fill="#fff" fillOpacity="0.5">
        {windows.map(([x, y]) => (
          <rect key={`${x}-${y}`} x={x} y={y} width="3" height="3" />
        ))}
      </g>
    </>
  ),
  space: (
    <>
      <g fill="#fff" fillOpacity="0.7">
        {stars.map(([x, y, r]) => (
          <circle key={`${x}-${y}`} cx={x} cy={y} r={r} />
        ))}
      </g>
      <circle cx="120" cy="115" r="54" fill="#000" fillOpacity="0.35" />
      <circle cx="120" cy="115" r="54" fill="#fff" fillOpacity="0.12" />
      <ellipse cx="120" cy="115" rx="90" ry="18" transform="rotate(-18 120 115)" stroke="#fff" strokeOpacity="0.45" strokeWidth="2" />
      <circle cx="38" cy="70" r="12" fill="#fff" fillOpacity="0.25" />
    </>
  ),
  mountains: (
    <>
      <circle cx="145" cy="85" r="30" fill="#fff" fillOpacity="0.22" />
      <circle cx="145" cy="85" r="52" stroke="#fff" strokeOpacity="0.12" />
      <path d="M-10 250 L55 140 L100 210 L140 150 L210 255 L210 320 L-10 320Z" fill="#000" fillOpacity="0.35" />
      <path d="M-10 285 L40 215 L90 265 L150 205 L210 275 L210 320 L-10 320Z" fill="#000" fillOpacity="0.55" />
    </>
  ),
  stadium: (
    <>
      <path d="M-10 185 Q100 125 210 185 L210 210 Q100 150 -10 210Z" fill="#000" fillOpacity="0.4" />
      {[28, 172].map((x) => (
        <g key={x}>
          <line x1={x} y1="60" x2={x} y2="140" stroke="#fff" strokeOpacity="0.4" />
          <circle cx={x} cy="52" r="16" fill="#fff" fillOpacity="0.16" />
          <g fill="#fff" fillOpacity="0.9">
            <circle cx={x - 6} cy="49" r="2.6" />
            <circle cx={x} cy="49" r="2.6" />
            <circle cx={x + 6} cy="49" r="2.6" />
            <circle cx={x - 6} cy="56" r="2.6" />
            <circle cx={x} cy="56" r="2.6" />
            <circle cx={x + 6} cy="56" r="2.6" />
          </g>
          <path d={`M${x} 60 L100 215 L${x < 100 ? x + 60 : x - 60} 215Z`} fill="#fff" fillOpacity="0.06" />
        </g>
      ))}
      <ellipse cx="100" cy="240" rx="130" ry="46" fill="#000" fillOpacity="0.3" />
      <ellipse cx="100" cy="240" rx="100" ry="32" stroke="#fff" strokeOpacity="0.4" />
      <line x1="100" y1="208" x2="100" y2="272" stroke="#fff" strokeOpacity="0.35" />
      <circle cx="100" cy="240" r="12" stroke="#fff" strokeOpacity="0.35" />
    </>
  ),
  rays: (
    <>
      {Array.from({ length: 11 }, (_, i) => {
        const angle = (Math.PI * 2 * i) / 11
        return (
          <line
            key={i}
            x1="100"
            y1="120"
            x2={100 + Math.cos(angle) * 260}
            y2={120 + Math.sin(angle) * 260}
            stroke="#fff"
            strokeOpacity="0.1"
            strokeWidth="12"
          />
        )
      })}
      <circle cx="100" cy="120" r="44" fill="#fff" fillOpacity="0.14" />
      <circle cx="100" cy="120" r="22" fill="#fff" fillOpacity="0.35" />
    </>
  ),
  ocean: (
    <>
      <circle cx="100" cy="140" r="34" fill="#fff" fillOpacity="0.25" />
      <circle cx="100" cy="140" r="58" stroke="#fff" strokeOpacity="0.12" />
      <path d="M-10 190 Q25 172 60 190 T130 190 T210 190 L210 320 L-10 320Z" fill="#000" fillOpacity="0.3" />
      <path d="M-10 225 Q25 207 60 225 T130 225 T210 225 L210 320 L-10 320Z" fill="#000" fillOpacity="0.35" />
      <path d="M-10 262 Q25 244 60 262 T130 262 T210 262 L210 320 L-10 320Z" fill="#000" fillOpacity="0.4" />
    </>
  ),
  figure: (
    <>
      <circle cx="100" cy="150" r="42" stroke="#fff" strokeOpacity="0.25" />
      <circle cx="100" cy="150" r="72" stroke="#fff" strokeOpacity="0.14" />
      <circle cx="100" cy="150" r="104" stroke="#fff" strokeOpacity="0.08" />
      <circle cx="100" cy="150" r="30" fill="#fff" fillOpacity="0.14" />
      <circle cx="100" cy="168" r="17" fill="#000" fillOpacity="0.75" />
      <path d="M58 300 L64 218 Q100 188 136 218 L142 300Z" fill="#000" fillOpacity="0.75" />
    </>
  ),
  bokeh: (
    <>
      {bokeh.map(([x, y, r, o]) => (
        <circle key={`${x}-${y}`} cx={x} cy={y} r={r} fill="#fff" fillOpacity={o} />
      ))}
      <circle cx="82" cy="150" r="40" stroke="#fff" strokeOpacity="0.3" />
      <circle cx="118" cy="150" r="40" stroke="#fff" strokeOpacity="0.3" />
    </>
  ),
}

/** Cena decorativa em SVG (arte própria, sem imagens de terceiros). */
export default function SceneArt({ scene }: { scene: SceneName }) {
  return (
    <svg
      className="absolute inset-0 h-full w-full"
      viewBox="0 0 200 300"
      preserveAspectRatio="xMidYMid slice"
      fill="none"
      aria-hidden="true"
      focusable="false"
    >
      {scenes[scene]}
    </svg>
  )
}
