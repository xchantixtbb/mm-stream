type Props = {
  id: string
  eyebrow: string
  title: string
  subtitle?: string
  align?: 'center' | 'left'
}

export default function SectionHeading({ id, eyebrow, title, subtitle, align = 'center' }: Props) {
  const alignment = align === 'center' ? 'mx-auto items-center text-center' : 'items-start text-left'

  return (
    <div className={`flex max-w-2xl flex-col ${alignment}`}>
      <span className="mb-4 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-brand-400">
        <span className="h-px w-6 bg-brand-500" aria-hidden="true" />
        {eyebrow}
      </span>
      <h2 id={id} className="font-display text-3xl font-extrabold leading-tight sm:text-4xl lg:text-5xl">
        {title}
      </h2>
      {subtitle ? <p className="mt-4 text-base text-white/70 sm:text-lg">{subtitle}</p> : null}
    </div>
  )
}
