import { Play } from 'lucide-react'
import type { Poster } from '../data/posters'
import SceneArt from './SceneArt'

type Props = {
  poster: Poster
  className?: string
}

/** Pôster decorativo e fictício (gerado em SVG/CSS). */
export default function PosterCard({ poster, className = '' }: Props) {
  const { title, genre, from, to, scene } = poster

  return (
    <div
      aria-hidden="true"
      className={`relative aspect-[2/3] w-full overflow-hidden rounded-2xl border border-white/10 shadow-poster ${className}`}
      style={{ background: `linear-gradient(160deg, ${from} 0%, ${to} 100%)` }}
    >
      <SceneArt scene={scene} />

      {/* brilho de luz no canto */}
      <div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(circle at 85% 8%, rgba(255,255,255,0.28), transparent 45%)' }}
      />
      {/* textura de filme */}
      <div
        className="absolute inset-0 opacity-60 mix-blend-overlay"
        style={{
          backgroundImage: 'radial-gradient(rgba(255,255,255,0.18) 1px, transparent 1px)',
          backgroundSize: '4px 4px',
        }}
      />
      {/* escurecimento para o título */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/10 to-black/30" />
      {/* vinheta */}
      <div className="absolute inset-0 rounded-2xl shadow-[inset_0_0_40px_rgba(0,0,0,0.55)]" />

      <span className="absolute left-3 top-3 rounded-full bg-black/55 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider backdrop-blur-sm">
        {genre}
      </span>

      <div className="absolute inset-x-3 bottom-3">
        <p className="font-display text-sm font-extrabold uppercase leading-tight tracking-wide drop-shadow sm:text-base">
          {title}
        </p>
        <div className="mt-2 flex items-center gap-2">
          <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-white text-ink">
            <Play size={11} fill="currentColor" />
          </span>
          <span className="h-1 flex-1 rounded-full bg-white/20">
            <span className="block h-full w-1/3 rounded-full bg-brand-500" />
          </span>
        </div>
      </div>
    </div>
  )
}
