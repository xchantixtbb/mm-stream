import { posters } from '../data/posters'
import PosterCard from './PosterCard'

type Slot = {
  index: number
  left: string
  top: string
  width: string
  rotate: number
  z: string
  float: string
  delay: string
}

const slots: Slot[] = [
  { index: 0, left: '0%', top: '14%', width: '34%', rotate: -9, z: 'z-10', float: 'animate-float-slow', delay: '0s' },
  { index: 1, left: '31%', top: '0%', width: '38%', rotate: 0, z: 'z-20', float: 'animate-float', delay: '0.4s' },
  { index: 2, left: '66%', top: '14%', width: '34%', rotate: 9, z: 'z-10', float: 'animate-float-slow', delay: '1.2s' },
  { index: 3, left: '6%', top: '52%', width: '32%', rotate: 6, z: 'z-20', float: 'animate-float', delay: '0.8s' },
  { index: 4, left: '60%', top: '54%', width: '32%', rotate: -6, z: 'z-20', float: 'animate-float-slow', delay: '1.6s' },
]

export default function HeroVisual() {
  return (
    <div className="relative mx-auto aspect-[4/5] w-full max-w-md lg:max-w-[540px]" aria-hidden="true">
      <div className="absolute inset-[10%] animate-glow rounded-full bg-brand-600/35 blur-[90px]" />

      {slots.map((slot) => (
        <div
          key={slot.index}
          className={`absolute ${slot.z}`}
          style={{
            left: slot.left,
            top: slot.top,
            width: slot.width,
            transform: `rotate(${slot.rotate}deg)`,
          }}
        >
          <div className={slot.float} style={{ animationDelay: slot.delay }}>
            <PosterCard poster={posters[slot.index]} />
          </div>
        </div>
      ))}

      <div className="absolute left-0 top-[46%] z-30 animate-float rounded-full border border-white/15 bg-ink-800/90 px-3 py-1.5 text-xs font-semibold shadow-poster sm:text-sm">
        <span className="mr-1.5 inline-block h-2 w-2 rounded-full bg-brand-500" />
        Filmes &amp; séries
      </div>
      <div
        className="absolute right-0 top-[40%] z-30 animate-float-slow rounded-full border border-white/15 bg-ink-800/90 px-3 py-1.5 text-xs font-semibold shadow-poster sm:text-sm"
        style={{ animationDelay: '1s' }}
      >
        <span className="mr-1.5 inline-block h-2 w-2 rounded-full bg-brand-400" />
        Novidades
      </div>
    </div>
  )
}
