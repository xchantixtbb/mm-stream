import { useEffect, useRef, useState } from 'react'
import { Menu, X } from 'lucide-react'
import { siteConfig } from '../config/site'
import { useActiveSection } from '../hooks/useActiveSection'
import { buildWhatsAppLink } from '../lib/whatsapp'
import Button from './Button'
import Logo from './Logo'

const SECTION_IDS = siteConfig.nav.map((item) => item.id)

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const active = useActiveSection(SECTION_IDS)
  const toggleRef = useRef<HTMLButtonElement>(null)
  const whatsappLink = buildWhatsAppLink()

  const close = () => setOpen(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    if (!open) return

    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setOpen(false)
        toggleRef.current?.focus()
      }
    }

    const mediaQuery = window.matchMedia('(min-width: 1024px)')
    const onChange = (event: MediaQueryListEvent) => {
      if (event.matches) setOpen(false)
    }

    document.addEventListener('keydown', onKeyDown)
    mediaQuery.addEventListener('change', onChange)

    return () => {
      document.body.style.overflow = previousOverflow
      document.removeEventListener('keydown', onKeyDown)
      mediaQuery.removeEventListener('change', onChange)
    }
  }, [open])

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled || open
          ? 'border-b border-white/10 bg-ink/85 backdrop-blur-xl'
          : 'border-b border-transparent bg-transparent'
      }`}
    >
      <div
        className={`container-x flex items-center justify-between transition-all duration-300 ${
          scrolled ? 'h-16' : 'h-[4.5rem] sm:h-20'
        }`}
      >
        <a
          href="#inicio"
          onClick={close}
          aria-label={`${siteConfig.name} — ir para o início`}
          className="rounded-md"
        >
          <Logo />
        </a>

        <nav aria-label="Principal" className="hidden items-center gap-8 lg:flex">
          <ul className="flex items-center gap-7">
            {siteConfig.nav.map((item) => {
              const isActive = active === item.id
              return (
                <li key={item.id}>
                  <a
                    href={`#${item.id}`}
                    aria-current={isActive ? 'location' : undefined}
                    className={`relative py-2 text-sm font-medium transition-colors hover:text-white after:absolute after:inset-x-0 after:-bottom-0.5 after:h-0.5 after:origin-left after:rounded-full after:bg-brand-500 after:transition-transform hover:after:scale-x-100 ${
                      isActive ? 'text-white after:scale-x-100' : 'text-white/70 after:scale-x-0'
                    }`}
                  >
                    {item.label}
                  </a>
                </li>
              )
            })}
          </ul>
          <Button href={whatsappLink} external size="sm">
            {siteConfig.navCta}
          </Button>
        </nav>

        <button
          ref={toggleRef}
          type="button"
          className="grid h-11 w-11 place-items-center rounded-full border border-white/15 bg-white/5 transition-colors hover:bg-white/10 lg:hidden"
          aria-label={open ? 'Fechar menu' : 'Abrir menu'}
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X size={22} aria-hidden="true" /> : <Menu size={22} aria-hidden="true" />}
        </button>
      </div>

      <div
        id="mobile-menu"
        hidden={!open}
        className="max-h-[calc(100dvh-4.5rem)] overflow-y-auto border-t border-white/10 bg-ink/95 lg:hidden"
      >
        <nav aria-label="Principal (mobile)" className="container-x animate-menu-in pb-8 pt-4">
          <ul>
            {siteConfig.nav.map((item) => {
              const isActive = active === item.id
              return (
                <li key={item.id} className="border-b border-white/10">
                  <a
                    href={`#${item.id}`}
                    onClick={close}
                    aria-current={isActive ? 'location' : undefined}
                    className={`block py-4 font-display text-lg font-semibold transition-colors ${
                      isActive ? 'text-brand-400' : 'text-white'
                    }`}
                  >
                    {item.label}
                  </a>
                </li>
              )
            })}
          </ul>
          <Button href={whatsappLink} external size="lg" className="mt-6 w-full" onClick={close}>
            {siteConfig.navCta}
          </Button>
        </nav>
      </div>
    </header>
  )
}
