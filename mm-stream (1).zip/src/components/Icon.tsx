import {
  Box,
  Cast,
  Clapperboard,
  Compass,
  Film,
  Gamepad2,
  Headset,
  Heart,
  Laptop,
  MonitorSmartphone,
  MousePointerClick,
  PlayCircle,
  RefreshCw,
  Smartphone,
  Sparkles,
  Trophy,
  Tv,
  UserPlus,
  Wallet,
  Zap,
  type LucideIcon,
} from 'lucide-react'
import type { IconName } from '../config/site'

const icons: Record<IconName, LucideIcon> = {
  clapperboard: Clapperboard,
  sparkles: Sparkles,
  zap: Zap,
  compass: Compass,
  devices: MonitorSmartphone,
  headset: Headset,
  wallet: Wallet,
  refresh: RefreshCw,
  plan: MousePointerClick,
  signup: UserPlus,
  play: PlayCircle,
  trophy: Trophy,
  film: Film,
  tv: Tv,
  heart: Heart,
  phone: Smartphone,
  laptop: Laptop,
  cast: Cast,
  gamepad: Gamepad2,
  box: Box,
}

type Props = {
  name: IconName
  className?: string
  size?: number
}

export default function Icon({ name, className, size = 24 }: Props) {
  const Component = icons[name]
  return <Component className={className} size={size} aria-hidden="true" />
}
