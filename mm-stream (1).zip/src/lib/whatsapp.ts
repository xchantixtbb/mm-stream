import { WHATSAPP_DEFAULT_MESSAGE, WHATSAPP_NUMBER } from '../config/site'

/**
 * Monta o link do WhatsApp com mensagem automática.
 * Se WHATSAPP_NUMBER estiver vazio, usa o link genérico (o visitante escolhe o contato).
 */
export function buildWhatsAppLink(message: string = WHATSAPP_DEFAULT_MESSAGE): string {
  const digits = WHATSAPP_NUMBER.replace(/\D/g, '')
  const text = encodeURIComponent(message)
  return digits ? `https://wa.me/${digits}?text=${text}` : `https://wa.me/?text=${text}`
}
