/* ==========================================================================
   M&M STREAM — CONFIGURAÇÃO CENTRAL
   Tudo o que você precisa editar com frequência está neste arquivo.
   ========================================================================== */

/** Nome da marca. */
export const BRAND_NAME = 'M&M Stream'

/* --------------------------------------------------------------------------
   >>> TELEFONE / WHATSAPP <<<
   WHATSAPP_NUMBER: código do país + DDD + número, somente dígitos.
   PHONE_DISPLAY: como o número aparece escrito no site.
   -------------------------------------------------------------------------- */
export const WHATSAPP_NUMBER = '5511924768708'
export const PHONE_DISPLAY = '+55 11 92476-8708'

/** Link de ligação (tel:) gerado a partir do número acima. */
export const PHONE_TEL = `tel:+${WHATSAPP_NUMBER}`

/** Mensagem automática padrão enviada ao WhatsApp. */
export const WHATSAPP_DEFAULT_MESSAGE = `Olá! Quero saber mais sobre o ${BRAND_NAME}.`

import type { SceneName } from '../components/SceneArt'

/* ---------------------------------- Tipos --------------------------------- */

export type IconName =
  | 'clapperboard'
  | 'sparkles'
  | 'zap'
  | 'compass'
  | 'devices'
  | 'headset'
  | 'wallet'
  | 'refresh'
  | 'plan'
  | 'signup'
  | 'play'
  | 'trophy'
  | 'film'
  | 'tv'
  | 'heart'
  | 'phone'
  | 'laptop'
  | 'cast'
  | 'gamepad'
  | 'box'

export type NavItem = { id: string; label: string }
export type Step = { number: string; icon: IconName; title: string; text: string }
export type Benefit = { icon: IconName; title: string; text: string }
export type Category = {
  icon: IconName
  scene: SceneName
  label: string
  text: string
  from: string
  to: string
}
export type Device = { icon: IconName; label: string }
export type FaqItem = { id: string; question: string; answer: string }
export type FooterLink = { label: string; href: string }

/* --------------------------------- Navegação ------------------------------- */

const navItems: NavItem[] = [
  { id: 'inicio', label: 'Início' },
  { id: 'como-funciona', label: 'Como funciona' },
  { id: 'beneficios', label: 'Benefícios' },
  { id: 'faq', label: 'FAQ' },
  { id: 'contato', label: 'Contato' },
]

/* ------------------------------- Como funciona ----------------------------- */

const steps: Step[] = [
  {
    number: '01',
    icon: 'plan',
    title: 'Chame no WhatsApp',
    text: 'Fale com a nossa equipe e tire todas as suas dúvidas antes de começar.',
  },
  {
    number: '02',
    icon: 'signup',
    title: 'Faça seu cadastro',
    text: 'Passe seus dados de forma simples, com o apoio do nosso atendimento.',
  },
  {
    number: '03',
    icon: 'play',
    title: 'Comece a aproveitar',
    text: 'Pronto! Agora é só escolher o que assistir e curtir a experiência.',
  },
]

/* --------------------------------- Categorias ------------------------------ */

const categories: Category[] = [
  { icon: 'trophy', scene: 'stadium', label: 'Esportes', text: 'Para quem vive o esporte.', from: '#14c957', to: '#04200f' },
  { icon: 'film', scene: 'rays', label: 'Filmes', text: 'Para todos os gostos.', from: '#4f46e5', to: '#0b0b2e' },
  { icon: 'tv', scene: 'space', label: 'Séries', text: 'Para maratonar.', from: '#0ea5a4', to: '#04222a' },
  { icon: 'heart', scene: 'bokeh', label: 'Doramas', text: 'Histórias para se emocionar.', from: '#ec4899', to: '#1f0a18' },
  { icon: 'clapperboard', scene: 'mountains', label: 'Novelas', text: 'Para matar a saudade.', from: '#f59e0b', to: '#2b1805' },
]

/* ------------------------------- Dispositivos ------------------------------ */

const devices: Device[] = [
  { icon: 'tv', label: 'Smart TV' },
]

/* --------------------------------- Benefícios ------------------------------ */

const benefits: Benefit[] = [
  {
    icon: 'clapperboard',
    title: 'Experiência completa de entretenimento',
    text: 'Filmes, séries e muito mais reunidos em um só lugar.',
  },
  {
    icon: 'sparkles',
    title: 'Interface simples',
    text: 'Navegação intuitiva, pensada para qualquer pessoa usar sem complicação.',
  },
  {
    icon: 'zap',
    title: 'Acesso fácil',
    text: 'Um processo direto para você começar sem dificuldades.',
  },
  {
    icon: 'compass',
    title: 'Conteúdo para diferentes gostos',
    text: 'Variedade pensada para atender diferentes perfis e momentos.',
  },
  {
    icon: 'devices',
    title: 'Feito para Smart TV',
    text: 'Disponível no momento para Smart TV, com uso simples na tela grande.',
  },
  {
    icon: 'headset',
    title: 'Suporte ao cliente',
    text: 'Conte com o nosso atendimento sempre que tiver dúvidas.',
  },
  {
    icon: 'wallet',
    title: 'Atendimento direto',
    text: 'Valores e condições explicados de forma clara, direto no WhatsApp.',
  },
  {
    icon: 'refresh',
    title: 'Atualizações constantes',
    text: 'Melhorias e novidades chegando de forma contínua.',
  },
]

/* ------------------------------------ FAQ ---------------------------------- */

const faqItems: FaqItem[] = [
  {
    id: 'o-que-e',
    question: `O que é o ${BRAND_NAME}?`,
    answer: `O ${BRAND_NAME} reúne diferentes opções de entretenimento em uma única experiência, com foco em simplicidade e praticidade para quem gosta de filmes, séries e muito mais.`,
  },
  {
    id: 'como-funciona',
    question: 'Como funciona?',
    answer:
      'É simples: você chama a nossa equipe no WhatsApp, faz seu cadastro e começa a aproveitar. Se tiver qualquer dúvida no caminho, é só falar com a gente.',
  },
  {
    id: 'dispositivos',
    question: 'Quais dispositivos são compatíveis?',
    answer:
      'No momento, o serviço está disponível para Smart TV. Fale com a nossa equipe para confirmar a compatibilidade com o seu modelo.',
  },
  {
    id: 'contratar',
    question: 'Como faço para contratar?',
    answer:
      'Clique em qualquer botão de contratação do site. Você será direcionado para o nosso atendimento no WhatsApp para concluir o processo.',
  },
  {
    id: 'valor',
    question: 'Quanto custa?',
    answer:
      'Os valores e as condições são informados no atendimento. Chame a nossa equipe no WhatsApp para saber mais.',
  },
  {
    id: 'cancelar',
    question: 'Posso cancelar?',
    answer:
      'Fale com a nossa equipe pelo WhatsApp para conhecer as condições de cancelamento.',
  },
  {
    id: 'suporte',
    question: 'Como funciona o suporte?',
    answer:
      'Nosso atendimento está disponível pelo WhatsApp para tirar dúvidas e ajudar você sempre que precisar.',
  },
  {
    id: 'comecar',
    question: 'Como começo a utilizar?',
    answer:
      'Depois de concluir sua contratação, nossa equipe orienta você nos primeiros passos para começar a aproveitar.',
  },
]

/* ----------------------------- Configuração geral -------------------------- */

export const siteConfig = {
  name: BRAND_NAME,
  tagline: 'Seu mundo do entretenimento em um só lugar.',
  navCta: 'ASSINE AGORA',
  nav: navItems,

  hero: {
    eyebrow: 'Seu mundo do entretenimento em um só lugar',
    titleLine1: 'Filmes, séries',
    titleHighlight: 'e muito mais!',
    subtitle:
      'Uma experiência de entretenimento simples de usar e feita para o seu dia a dia. Fale com a gente e comece agora.',
    primaryCta: 'ASSINE AGORA MESMO',
    secondaryCta: 'Como funciona',
    highlights: ['Cadastro simples', 'Suporte pelo WhatsApp', 'Feito para Smart TV'],
  },

  categories: {
    eyebrow: 'Categorias',
    title: 'Tudo o que você gosta, quando quiser',
    subtitle: 'Escolha o seu estilo e aproveite do seu jeito.',
    items: categories,
  },

  devices: {
    title: 'Disponível para Smart TV',
    subtitle: 'No momento, o serviço funciona em Smart TV. Fale com a gente para confirmar o seu modelo.',
    items: devices,
  },

  howItWorks: {
    eyebrow: 'Como funciona',
    title: 'Comece em 3 passos simples',
    subtitle: 'Sem complicação: do primeiro clique ao primeiro play.',
    cta: 'Falar no WhatsApp',
    steps,
  },

  benefits: {
    eyebrow: 'Benefícios',
    title: `Por que escolher o ${BRAND_NAME}?`,
    subtitle: 'Tudo pensado para deixar o seu entretenimento mais simples e prático.',
    cta: 'Quero conhecer',
    items: benefits,
  },

  featured: {
    eyebrow: 'Experiência',
    titleLead: 'Tudo o que você gosta.',
    titleHighlight: 'Em uma experiência simples.',
    text: 'Entretenimento reunido em um só lugar, com atendimento direto e visual pensado para você aproveitar cada momento.',
    pills: ['Filmes', 'Séries', 'Para todos os gostos'],
    cta: 'COMEÇAR AGORA',
  },

  cta: {
    title: 'Pronto para transformar sua experiência de entretenimento?',
    text: 'Fale com a nossa equipe e comece a aproveitar o seu mundo do entretenimento.',
    button: 'QUERO FAZER PARTE',
    note: 'Ou ligue / chame no WhatsApp:',
  },

  faq: {
    eyebrow: 'FAQ',
    title: 'Perguntas frequentes',
    subtitle: 'Respostas rápidas para as dúvidas mais comuns.',
    moreDoubts: 'Ainda tem dúvidas?',
    moreDoubtsCta: 'Falar com a equipe',
    items: faqItems,
  },

  /* >>> COLOQUE AQUI OS LINKS DAS SUAS REDES SOCIAIS <<<
     Deixe vazio ('') para o ícone aparecer desativado ("em breve"). */
  social: {
    instagram: '',
    tiktok: '',
    facebook: '',
  },

  footer: {
    navLinks: [
      { label: 'Início', href: '#inicio' },
      { label: 'Benefícios', href: '#beneficios' },
      { label: 'FAQ', href: '#faq' },
      { label: 'Contato', href: '#contato' },
    ] as FooterLink[],
    /* >>> TROQUE '#' PELAS URLS DAS SUAS PÁGINAS DE TERMOS E PRIVACIDADE <<< */
    legalLinks: [
      { label: 'Termos de Uso', href: '#' },
      { label: 'Política de Privacidade', href: '#' },
    ] as FooterLink[],
    copyright: `© 2026 ${BRAND_NAME}. Todos os direitos reservados.`,
  },
}
