/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#07070a',
          900: '#0b0b10',
          800: '#111118',
          700: '#1a1a23',
          600: '#262632',
        },
        brand: {
          300: '#8dffb0',
          400: '#4dff88',
          500: '#1fe86a',
          600: '#14c957',
          700: '#0e9441',
          800: '#0a5c2b',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
        display: ['Sora', 'Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'Arial', 'sans-serif'],
      },
      boxShadow: {
        glow: '0 8px 30px -6px rgba(31, 232, 106, 0.55)',
        'glow-lg': '0 12px 44px -6px rgba(31, 232, 106, 0.75)',
        poster: '0 20px 40px -12px rgba(0, 0, 0, 0.8)',
      },
      keyframes: {
        float: { '0%, 100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-12px)' } },
        glow: { '0%, 100%': { opacity: '0.55' }, '50%': { opacity: '1' } },
        shift: { '0%, 100%': { backgroundPosition: '0% 50%' }, '50%': { backgroundPosition: '100% 50%' } },
        fadeUp: { '0%': { opacity: '0', transform: 'translateY(22px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        menuIn: { '0%': { opacity: '0', transform: 'translateY(-8px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        marquee: { '0%': { transform: 'translateX(0)' }, '100%': { transform: 'translateX(-50%)' } },
        marqueeReverse: { '0%': { transform: 'translateX(-50%)' }, '100%': { transform: 'translateX(0)' } },
        pulseRing: { '0%': { boxShadow: '0 0 0 0 rgba(255, 255, 255, 0.35)' }, '70%, 100%': { boxShadow: '0 0 0 18px rgba(255, 255, 255, 0)' } },
        waPulse: { '0%': { boxShadow: '0 0 0 0 rgba(37, 211, 102, 0.5)' }, '70%, 100%': { boxShadow: '0 0 0 16px rgba(37, 211, 102, 0)' } },
      },
      animation: {
        float: 'float 6s ease-in-out infinite',
        'float-slow': 'float 9s ease-in-out infinite',
        glow: 'glow 5s ease-in-out infinite',
        shift: 'shift 8s ease-in-out infinite',
        'fade-up': 'fadeUp 0.8s cubic-bezier(0.2, 0.7, 0.2, 1) both',
        'menu-in': 'menuIn 0.25s ease-out both',
        marquee: 'marquee 45s linear infinite',
        'marquee-reverse': 'marqueeReverse 50s linear infinite',
        'pulse-ring': 'pulseRing 2.4s ease-out infinite',
        'wa-pulse': 'waPulse 2.6s ease-out infinite',
      },
    },
  },
  plugins: [],
}
