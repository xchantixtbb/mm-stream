# M&M Stream

Landing page de conversão feita com React + Vite + TypeScript + Tailwind CSS.

## Rodar no computador

```bash
npm install
npm run dev
```

Abra o endereço mostrado no terminal (normalmente http://localhost:5173).

## Gerar build

```bash
npm run build
npm run preview
```

## Personalizar (tudo em `src/config/site.ts`)

- Nome da marca: `BRAND_NAME`
- Telefone/WhatsApp: `WHATSAPP_NUMBER` e `PHONE_DISPLAY`
- Categorias, dispositivos, benefícios, FAQ e textos: dentro de `siteConfig`
- Redes sociais: objeto `social`
- Termos e Privacidade: `footer.legalLinks`

## Antes de publicar

1. Em `index.html`, troque `https://www.seudominio.com.br` pelo seu domínio.
2. Exporte `public/og-image.svg` como PNG 1200x630 e atualize a referência (redes sociais não exibem SVG).
3. Publicação: Vercel, Netlify ou Cloudflare Pages (build `npm run build`, saída `dist`).

## Conformidade

Todos os pôsteres e títulos são fictícios (CSS/SVG). Não use logos de plataformas de terceiros,
imagens de filmes/séries ou fotos de atores sem autorização, e só divulgue conteúdo que você tenha
direito de oferecer.
